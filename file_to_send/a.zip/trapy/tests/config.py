import os

MININET_LOG_LEVEL = os.getenv('MININET_LOG_LEVEL', 'info')

PYTHON = os.getenv('PYTHON', 'python3.7')
